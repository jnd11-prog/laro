# Laro FC

Laro FC is a soccer career simulator that teaches Tagalog. Shelomi built it for her boyfriend and his friends. Keep the pixel arcade design, readable hierarchy, and short quiz interruptions.

## Architecture

- React and TypeScript use the Vinext app router. The runtime is a Cloudflare Worker.
- `app/game.tsx` owns the game UI, quiz screen, phrasebook, kit locker, and creator studio.
- `app/art.tsx` renders pixel artwork and the weighted wheel. `app/globals.css` contains responsive styling.
- `lib/engine.ts` grades exercises, schedules review, awards XP, and connects the career simulator to the game.
- `lib/player-career.js` replays the seeded career builder and its branching question sequence. `lib/player-career.d.ts` is its typed boundary.
- `lib/quiz.ts` controls which phrase information may be shown before and after a correct answer.
- `lib/server.ts` handles identity, membership, D1 persistence, and atomic mutation checks. `app/api/[...route]/route.ts` exposes the HTTP API.
- D1 stores career state, memberships, custom phrases, and idempotency records. R2 holds pronunciation recordings.

## Setup and validation

Use Node.js 22.13 or newer and the package manager pinned in `package.json` (pnpm 11.25.0). Install with `pnpm install --frozen-lockfile`. Do not replace the lockfile or switch package managers.

Run checks from the repository root:

```sh
node node_modules/typescript/bin/tsc --noEmit
node --experimental-strip-types --test tests/engine.test.mjs
python3 tests/storage.test.py
pnpm build
```

The current domain and SQLite suites contain 20 tests. The domain suite runs complete careers across 30 seeds. Add targeted regressions when changing behavior rather than hard-coding these counts.

For a new local database, run `pnpm build`, apply the SQL migration once using the command in `README.md`, then run `pnpm dev`. A clean clone selects the portable preview profile automatically. Do not claim the HTTP integration suite passed unless it was actually run against an isolated test instance.

## Behavior that must remain correct

- Never show a complete Tagalog phrase on a checkpoint wheel. Wheel labels use categories. The quiz removes the career workspace, wheel, and recent history from the rendered page while open, including for saved older challenges.
- Missing-word exercises show a Tagalog cue with a blank; word-order exercises hide the complete phrase. English glosses and usage explanations appear only after a correct answer. Wrong answers do not earn XP or reveal hints.
- Grade answers and validate kit eligibility on the server. Replayed request IDs must not award duplicate XP. Version conflicts must reload current state rather than silently overwrite it.
- Preserve club and actor boundaries. Only the owner can edit lessons. Recordings may only be served to members of the relevant club.
- Keep seeded simulation state request-local. Replay must validate stage IDs and available outcomes. Wheel geometry and landing must agree with backend weights; blocked outcomes cannot land.
- Auto-spin pauses for quizzes and when the page is hidden. Manual mode waits for the next-question action. Preserve reduced-motion behavior and existing saved XP, kits, trophies, and reviews.
- Audio recordings are optional. Device speech depends on an installed Filipino voice; never label generated audio as Shelomi's voice.

## Working practices

Make focused changes and preserve unrelated code and user data. Use meaningful tests for changes to scoring, persistence, or simulation rules. Keep credentials, production recordings, local databases, and build output out of Git. Preserve existing third-party license notices and the supplied career-question provenance in the README. Do not add unsupported user counts, learning outcomes, or performance claims.

Deployment configuration lives in `.openai/hosting.json`. This export retains the existing Site identity; do not register it as a new Site or change its sharing configuration as part of an unrelated code task.
