# Laro FC for GitHub Copilot

This folder contains the application source, backend routes, SQL migration, tests, and repository instructions for Copilot. It excludes installed dependencies, local databases, recordings, build output, credentials, and Git history.

The live app is https://laro-fc.jnd11276870.chatgpt.site.

## Local setup

Use Node.js 22.13 or newer and pnpm 11.25.0. Follow the setup and migration commands in `README.md` before the first local run.

## Continue with Copilot

Open the repository in your editor with GitHub Copilot enabled, or select the repository in Copilot on GitHub. The `.github/copilot-instructions.md` file supplies the architecture, validation commands, and behavior that must stay correct.

A useful first request is:

> Read README.md and .github/copilot-instructions.md. Explain the quiz and career state flow, run the available checks, and identify one small improvement with a concrete regression test. Preserve existing scoring, saved progress, and the rule that quiz answers never appear on the wheel.

Official reference: https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/add-custom-instructions/add-repository-instructions
